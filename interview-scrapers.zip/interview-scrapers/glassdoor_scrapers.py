from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

def scrape_glassdoor(count=5):
    options = Options()
    options.add_argument("--headless")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    driver.get("https://www.glassdoor.com/Interview/index.htm")
    time.sleep(3)

    results = []
    interview_links = driver.find_elements(By.CSS_SELECTOR, "a.reviewLink")[:count]
    for link in interview_links:
        try:
            link.click()
            time.sleep(2)
            content = driver.find_element(By.CLASS_NAME, "interviewQuestionsContainer").text
            title = driver.find_element(By.CLASS_NAME, "heading-5").text
            results.append({
                "company": title.split()[0] if title else "Unknown",
                "role": "Unknown",
                "content": content,
                "source": "Glassdoor",
                "url": driver.current_url
            })
            driver.back()
            time.sleep(1)
        except:
            continue

    driver.quit()
    return results
