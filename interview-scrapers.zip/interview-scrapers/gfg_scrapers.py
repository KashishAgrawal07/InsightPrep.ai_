from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time
import json

def scrape_gfg_selenium(pages=2):
    options = Options()
    # Comment this line if you want to see the browser window
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    # Start browser
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    results = []
    base_url = "https://www.geeksforgeeks.org/category/interview-experiences"

    for page in range(1, pages + 1):
        url = base_url if page == 1 else f"{base_url}/page/{page}/"
        print(f"📄 Fetching GFG page {page}: {url}")
        driver.get(url)
        time.sleep(2)  # wait for JS to load

        # 🍪 Dismiss GDPR cookie banner
    try:
        accept_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Accept')]")
        accept_button.click()
        print("🍪 Accepted cookie banner")
    except:
        pass

        # Optional: Take screenshot for debugging
        driver.save_screenshot(f"page{page}.png")

        soup = BeautifulSoup(driver.page_source, "html.parser")

        # 🔍 Updated selector: works with current GFG structure
        links = soup.select("a[href*='/interview-experiences/']")

        print(f"🔍 Found {len(links)} article links")

        for a_tag in links:
            post_url = a_tag.get("href")
            title = a_tag.get_text(strip=True)

            try:
                driver.get(post_url)
                time.sleep(1)
                post_soup = BeautifulSoup(driver.page_source, "html.parser")
                content_div = post_soup.find("div", class_="text")
                content = content_div.get_text(separator="\n").strip() if content_div else ""

                if content:
                    results.append({
                        "company": title.split()[0],
                        "role": "Unknown",
                        "content": content,
                        "source": "GeeksforGeeks",
                        "url": post_url
                    })
                    print(f"✅ Scraped: {title}")
                else:
                    print(f"⚠️ No content at: {post_url}")
            except Exception as e:
                print(f"❌ Error scraping {post_url}: {e}")

    driver.quit()
    return results


if __name__ == "__main__":
    data = scrape_gfg_selenium(pages=2)

    # ✅ Save to JSON
    with open("gfg_interview_data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Scraped {len(data)} interview experiences from GeeksforGeeks.")
    print("📁 Data saved to gfg_interview_data.json")
