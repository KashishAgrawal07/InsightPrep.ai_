import requests
from bs4 import BeautifulSoup

def scrape_leetcode(pages=2):
    base_url = "https://leetcode.com/discuss/interview-experience?page={}"
    headers = {"User-Agent": "Mozilla/5.0"}
    results = []
    for page in range(1, pages+1):
        res = requests.get(base_url.format(page), headers=headers)
        soup = BeautifulSoup(res.text, "html.parser")
        posts = soup.select("a.title")
        for post in posts:
            url = "https://leetcode.com" + post.get("href")
            title = post.text.strip()
            post_res = requests.get(url, headers=headers)
            post_soup = BeautifulSoup(post_res.text, "html.parser")
            content_div = post_soup.find("div", class_="post__content")
            content = content_div.get_text(separator="\n").strip() if content_div else ""
            results.append({
                "company": title.split()[0] if title else "Unknown",
                "role": "Unknown",
                "content": content,
                "source": "LeetCode",
                "url": url
            })
    return results

