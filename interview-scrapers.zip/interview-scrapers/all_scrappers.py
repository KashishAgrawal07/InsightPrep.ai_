from gfg_scrapers import scrape_gfg
from leet_scrapper import scrape_leetcode
from glassdoor_scrapers import scrape_glassdoor
import json

print("Scraping from GeeksforGeeks...")
gfg_data = scrape_gfg()
print(f"✅ {len(gfg_data)} entries from GFG")

print("Scraping from LeetCode...")
lc_data = scrape_leetcode()
print(f"✅ {len(lc_data)} entries from LeetCode")

print("Scraping from Glassdoor...")
gd_data = scrape_glassdoor()
print(f"✅ {len(gd_data)} entries from Glassdoor")

all_data = gfg_data + lc_data + gd_data

with open("interview_data.json", "w", encoding="utf-8") as f:
    json.dump(all_data, f, indent=2, ensure_ascii=False)

print(f"🎉 Total {len(all_data)} interview experiences saved to interview_data.json")